package org.example.staystylish.domain.weather.client;

import java.time.LocalDate;
import java.util.List;
import reactor.core.publisher.Mono;

public interface WeatherApiClient {

    // 도시 + 기간(14일) 일별 평균치 목록 조회
    Mono<List<Daily>> getDailyForecast(String city, LocalDate start, LocalDate end);

    // 서비스 계층으로 전달
    record Daily(Double avgTempC, Double avgHumidity, Integer rainChance, String conditionText) {
    }
}
