package org.example.staystylish.domain.user.entity;

public enum Provider {
    LOCAL, GOOGLE
}
