package org.example.staystylish.domain.user.entity;

public enum Role {
    USER, ADMIN
}
