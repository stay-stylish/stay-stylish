package org.example.staystylish.domain.user.entity;

public enum Gender {
    MALE, FEMALE
}
