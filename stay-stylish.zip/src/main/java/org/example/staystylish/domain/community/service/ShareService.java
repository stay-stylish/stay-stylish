package org.example.staystylish.domain.community.service;

import lombok.RequiredArgsConstructor;
import org.example.staystylish.domain.community.consts.CommunityErrorCode;
import org.example.staystylish.domain.community.dto.response.ShareResponse;
import org.example.staystylish.domain.community.entity.Post;
import org.example.staystylish.domain.community.entity.Share;
import org.example.staystylish.domain.community.exception.CommunityException;
import org.example.staystylish.domain.community.repository.PostRepository;
import org.example.staystylish.domain.community.repository.ShareRepository;
import org.example.staystylish.domain.user.entity.User;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class ShareService {

    private final PostRepository postRepository;
    private final ShareRepository shareRepository;

    @Transactional
    public ShareResponse sharePost(User user, Long postId, String platform) {
        Post post = postRepository.findById(postId)
                .orElseThrow(() -> new CommunityException(CommunityErrorCode.POST_NOT_FOUND));

        if (platform == null || platform.isBlank()) {
            throw new CommunityException(CommunityErrorCode.INVALID_PLATFORM);
        }

        shareRepository.save(Share.builder()
                .post(post)
                .user(user)
                .platform(platform.toUpperCase())
                .build());

        post.increaseShare();
        return ShareResponse.of(post.getId(), platform.toUpperCase(), post.getShareCount());
    }
}

