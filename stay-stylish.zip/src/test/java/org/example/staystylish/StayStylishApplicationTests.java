package org.example.staystylish;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StayStylishApplicationTests {

    @Test
    void contextLoads() {
    }

}
