import random
import logging
from locust import HttpUser, task, between
from datetime import datetime, timedelta

# --- [!] 사용자 설정 필요 [!] ---
# 부하 테스트에 사용할 테스트 계정의 이메일과 비밀번호를 입력하세요.
# (이전 테스트에서 사용한 것과 동일한 계정 사용)
TEST_USER_EMAIL = "youngrae0317@gmail.com"
TEST_USER_PASSWORD = "password123!"
# ---------------------------------

class TravelOutfitCreatorUser(HttpUser):
    """
    '해외 여행 옷차림 추천 생성' (POST /recommendations) 시나리오를 테스트합니다.
    이 API는 외부 AI를 호출하므로 비용이 발생하고 응답 시간이 깁니다.

    1. (on_start) 테스트 사용자로 로그인하여 JWT 토큰을 발급받습니다.
    2. (task) 20~40초마다 한 번씩, 랜덤한 여행지와 날짜로 추천 생성을 요청합니다.
    """

    # API 호출 비용과 긴 응답 시간을 고려하여,
    # 각 사용자가 20초에서 40초 사이의 긴 대기 시간을 가집니다.
    wait_time = between(20, 40)

    # 테스트에 사용할 토큰
    auth_header = None

    # 테스트에 사용할 랜덤 여행지 목록
    test_destinations = [
        {"country": "Japan", "city": "Tokyo"},
        {"country": "France", "city": "Paris"},
        {"country": "USA", "city": "New York"},
        {"country": "UK", "city": "London"},
        {"country": "Thailand", "city": "Bangkok"},
        {"country": "Spain", "city": "Barcelona"},
        {"country": "Italy", "city": "Rome"}
    ]

    def on_start(self):
        """테스트 사용자가 시작될 때 1회 실행됩니다. (로그인)"""
        try:
            response = self.client.post("/api/v1/auth/login", json={
                "email": TEST_USER_EMAIL,
                "password": TEST_USER_PASSWORD
            })
            response.raise_for_status() # 2xx가 아니면 예외 발생

            data = response.json().get("data")
            if not data or "accessToken" not in data:
                logging.error(f"Login failed: 'data.accessToken' not found. {response.text}")
                self.locust.runner.quit()
                return

            token = data["accessToken"]
            self.auth_header = {"Authorization": f"Bearer {token}"}
            logging.info(f"Login successful for user: {TEST_USER_EMAIL}")

        except Exception as e:
            logging.error(f"Login failed for user {TEST_USER_EMAIL}: {e}")
            self.locust.runner.quit()

    @task
    def create_recommendation(self):
        """(Task) 랜덤한 여행 정보로 추천 생성을 요청합니다."""
        if not self.auth_header:
            return # 로그인이 실패한 유저는 요청을 보내지 않습니다.

        try:
            # 1. 랜덤 여행지 선택
            destination = random.choice(self.test_destinations)

            # 2. 랜덤 날짜 생성 (백엔드 14일 제한 준수)
            today = datetime.now()

            # [수정됨] 여행 기간 (3~7일)을 먼저 결정
            duration_days = random.randint(3, 7)

            # [수정됨] 총 기간이 14일을 넘지 않도록 출발일(daysToStart)의 최대값을 제한
            # (14 - (duration_days + 1))
            max_start_offset = 14 - (duration_days + 1)
            start_day_offset = random.randint(1, max(1, max_start_offset)) # 1~ (14-여행기간-1)일 뒤 출발

            start_date = today + timedelta(days=start_day_offset)
            end_date = start_date + timedelta(days=duration_days)

            # API DTO 형식에 맞게 payload 생성
            payload = {
                "country": destination["country"],
                "city": destination["city"],
                "startDate": start_date.strftime("%Y-%m-%d"),
                "endDate": end_date.strftime("%Y-%m-%d")
            }

            # API 호출
            with self.client.post(
                "/api/v1/travel-outfits/recommendations",
                headers=self.auth_header,
                json=payload,
                name="/api/v1/travel-outfits/recommendations (POST)",
                catch_response=True # 응답을 수동으로 처리하기 위함
            ) as response:
                if response.ok:
                    response.success()
                else:
                    # API가 2xx(성공)가 아닌 4xx, 5xx 등을 반환한 경우 실패로 기록
                    response.failure(f"Request failed with {response.status_code} - {response.text}")

        except Exception as e:
            logging.error(f"Task failed with exception: {e}")
            if 'response' in locals():
                response.failure(str(e))

